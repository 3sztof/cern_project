Ext.define('LHCb.variables.GlobalVariables', {
    singleton: true,
    request_path: "http://localhost:8081/TDBDATA/JSONRPC"

});