Ext.define('LHCb.store.AssignItemsStore', {
    extend: 'Ext.data.Store',
    alias: 'store.assignitemsstore',
    singleton : true,

    autoLoad: true,

    // fields: [
    //     'task', 'description', 'utgid', 'command', 'command_parameters', 'task_parameters'
    // ],

    // task: '',
    // description: '',
    // utgid: '',
    // command: '',
    // command_parameters: '',
    // task_parameters: ''

}); 

