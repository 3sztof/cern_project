Ext.define('LHCb.store.UnassignItemsStore', {
    extend: 'Ext.data.Store',
    alias: 'store.unassignitemsstore',
    singleton : true,

    autoLoad: true,

    // fields: [
    //     'task', 'description', 'utgid', 'command', 'command_parameters', 'task_parameters'
    // ],

    // task: '',
    // description: '',
    // utgid: '',
    // command: '',
    // command_parameters: '',
    // task_parameters: ''

}); 